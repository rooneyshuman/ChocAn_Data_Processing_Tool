1) Environment

  Our program is built with IntelliJ and programmed using Java.
  All that's required is to have Java downloaded.

2) Running the Project

  To run the project, open up the command line interface of your operating system.
  Navigate to the folder with our program.
  Type the following:
    java -jar chocan.jar

3) Accounts for Testing

  Member accounts are stored in: /db/members.txt
  Alternatively, you can test member ID 600000002.

  Provider accounts are stored in: /db/providers.txt
  Alternatively, you can test provider ID 700000002.

  Manager accounts are stored in: /db/managers.txt
  Alternatively, you can test manager ID 800000002.

4) Reports

  Service records are stored in: /db/services.txt

  Member reports are stored in: /report/member/

  Provider reports are stored in: /report/provider/

  Manager reports are stored in: /report/manager/

  EFT records are stored in: /report/EFT.txt

  Provider directory is stored in: /db/provider directory.txt

5) Documentation

  For a more comprehensive README detailing the program, visit: https://github.com/Gilmore-PDX-CS/Team6

  The project retrospective and presentation slides are stored in: /documentation
